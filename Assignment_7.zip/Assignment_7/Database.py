import psycopg2
def create_table():
    
    connect = psycopg2.connect(dbname="postgres", user="postgres", password="postgresql",host="localhost", port="5432")
    cursor = connect.cursor()
    cursor.execute('''create table employees(emp_name text,emp_id int,age int,address text ); ''')

    print("Table created successfully")
    connect.commit()
    connect.close()

def insert_data():
    connect = psycopg2.connect(dbname="postgres", user="postgres", password="postgresql",host="localhost", port="5432")
    cursor = connect.cursor()
    cursor.execute('''insert into employees(emp_name,emp_id,age,address) values('Bikash',1,25,'Odisha, India'); ''')
    print("Data inserted successfully")
    connect.commit()
    connect.close()

def fetch_data():
    connect = psycopg2.connect(dbname="postgres", user="postgres", password="postgresql",host="localhost", port="5432")
    cursor = connect.cursor()
    cursor.execute('''select * from employees; ''')
    show = cursor.fetchone()
    print(show[3])
    connect.commit()
    connect.close()

def insert_data_by_user():
    connect = psycopg2.connect(dbname="postgres", user="postgres", password="postgresql",host="localhost", port="5432")
    cursor = connect.cursor()
    emp_name = input("Enter employee name: ")
    emp_id = int(input("Enter employee id: "))
    age = int(input("Enter employee age: "))
    address = input("Enter employee address: ")
    query = '''insert into employees(emp_name,emp_id,age,address) values(%s,%s,%s,%s); '''
    cursor.execute(query, (emp_name, emp_id, age, address))
    print("Data inserted successfully")
    connect.commit()
    connect.close()  
      
insert_data_by_user()
#fetch_data()
#create_table()
#insert_data()    
